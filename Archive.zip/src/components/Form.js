import React, { Component } from 'react';
// material UI
import Typography from '@material-ui/core/Typography';
import { Link } from 'react-router-dom';
import Button from '@material-ui/core/Button';
import AddIcon from '@material-ui/icons/Add';

import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';

import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';

import Paper from '@material-ui/core/Paper';


class Form extends Component {
  state = {
   open: false,
   name: 'Niet'
 };

 handleClickOpen = () => {
   this.setState({ open: true });
 };

 handleClose = () => {
   this.setState({ open: false });
 };

 handleChange = event => {
    this.setState({ name: event.target.value });
  };

 updateFormName = event => {
   console.log(event);
   event.preventDefault();

 }

  render() {
    const styles = theme => ({
      container: {
        display: 'flex',
        flexWrap: 'wrap',
      },
      formControl: {
        margin: theme.spacing.unit,
      },
      button: {
        margin: theme.spacing.unit,
      }
    });

    return (
      <div>
        <h2>Form</h2>
        <Dialog
          open={this.state.open}
          onClose={this.handleClose}
          aria-labelledby="form-dialog-title"
        >
          <form onSubmit={ e => this.updateFormName(e)}>
          <DialogTitle id="form-dialog-title">Subscribe</DialogTitle>
          <DialogContent>
            <FormControl className={styles.formControl}>
              <InputLabel htmlFor="name-simple">Name</InputLabel>
              <Input id="name-simple"  />
            </FormControl>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary">
              Cancel
            </Button>
            <Button type="submit" onClick={this.handleClose} color="primary">
              Subscribe
            </Button>
          </DialogActions>
          </form>
        </Dialog>
        <Button variant="fab"
                color="secondary"
                aria-label="Add"
                className={styles.button}
                onClick={this.handleClickOpen}>
          <AddIcon />
        </Button>

        <Paper className={styles.root} elevation={1}>
          <Typography variant="headline" component="h3">
            My name is
          </Typography>
          <Typography component="p">
            {this.state.name}
          </Typography>
        </Paper>
      </div>
      )
    }
  };
export default Form;
